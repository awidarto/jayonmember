Hi {full_name},

Please click on this link to verify your email address and complete your registration on Jayon Express.
Verify {e-mail}

If you can't click on the link above, you can verify your email address by cutting and pasting (or typing) the following address into your browser:

http://www.jayonexpress.com/verifyuser.php?{string}

Thank you,
Jayon Express Team