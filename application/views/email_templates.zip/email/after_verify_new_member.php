Thank you for confirming your e-mail address.

You are now registered as a buyer and may choose Jayon Express COD payment option at participating online stores.

If you are an online merchant and would like to have Jayon Express COD payment option on your online store, kindly fill out the ‘Merchant Membership Request Form’ available at the above menu tab on your profile page.

Thank you,
Jayon Express Team