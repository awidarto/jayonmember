Hello {full_name},

You are receiving this email because you or someone else requested a password reset for your Jayon Express account. 
If it wasn't you, please ignore this email.

There are two options to reset your password:
Option 1 - please click the verification link below to reset your Jayon Express password: http://www.jayonexpress.com/reset_password/confirm/{string}

Option 2 - if the link above does not work for you, please go to http://www.jayonexpress.com/reset_password/confirm/
And copy and paste this confirmation code: {string}
This may be needed if your email program prevents linking, or the link gets corrupted.
The confirmation code is valid for 72 hours.

Questions/comments? Please do not reply to this email.
Instead, please visit http://www.jayonexpress.com/contact.php

Thank you,
Jayon Express team