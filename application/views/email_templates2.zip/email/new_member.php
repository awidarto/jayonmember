<html>
<body>
<p>Hello <?php print $fullname?>,</p>

<p>
You are now registered as a buyer and choose Jayon Express COD payment option at participating online stores.<br />
Please verify the details you submitted below.
</p>
<p>
Name: <?php print $fullname?><br />
E-mail address: <?php print $email?><br />
Password: <?php print $password?><br />
</p>
<p>You may login using your email or username you have set on registration form.</p>

<p>
If you are an online merchant and would like to have Jayon Express COD payment option on your online store, 
kindly fill out the merchant membership request form available under 'Become a Merchant' menu tab on your member page.
</p>
<p>Kindly keep this e-mail for your record.</p>
<p>
	Thank you,
	Jayon Express team
</p>
</body>
</html>