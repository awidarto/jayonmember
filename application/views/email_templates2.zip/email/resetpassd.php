Hello <?php print $fullname; ?>,

You are receiving this email because you or someone else requested a password reset for your Jayon Express account. 
If it wasn't you, please ignore this email.

Your password has been reset to : <?php print $password; ?>

Questions/comments? Please do not reply to this email.
Instead, please visit http://www.jayonexpress.com/contact.php

Thank you,
Jayon Express team